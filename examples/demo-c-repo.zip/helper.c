#include <stdio.h>
#include "helper.h"

void greet() {
    printf("Hello from the helper function!\n");
}
