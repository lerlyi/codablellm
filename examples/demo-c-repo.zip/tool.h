#ifndef TOOL_H
#define TOOL_H

void perform_task();

#endif
