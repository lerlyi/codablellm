#include <stdio.h>
#include "helper.h"

int main() {
    printf("Main app started.\n");
    greet();
    printf("Main app finished.\n");
    return 0;
}
