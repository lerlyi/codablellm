#include <stdio.h>
#include "helper.h"
#include "tool.h"

int main() {
    printf("Tool started.\n");
    perform_task();
    printf("Tool finished.\n");
    return 0;
}

void perform_task() {
    printf("Performing a tool task.\n");
    greet();
}
