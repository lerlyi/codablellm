#ifndef HELPER_H
#define HELPER_H

void greet();

#endif
